package pa;

public class Nodo {
	private int numeroNodo;

	public Nodo(int numeroDeNodo) {
		this.numeroNodo = numeroDeNodo;
	}

	public int getNumero() {
		return numeroNodo;
	}
}
