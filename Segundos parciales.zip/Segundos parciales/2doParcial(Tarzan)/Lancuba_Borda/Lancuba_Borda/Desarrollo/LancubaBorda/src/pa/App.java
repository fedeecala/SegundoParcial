package pa;

import java.io.FileNotFoundException;

public class App {

	public static void main(String[] args) {
		try {
			Tarzan tarzan = ArchivoTarzan
					.leerArchivo("../../Preparacion de la Prueba/Lote de Prueba/Entrada/01_enunciado.in");
			ArchivoTarzan.escribirArchivo("../../Ejecucion de Prueba/Salida Obtenida/01_enunciado.out",
					tarzan.resolver());

			tarzan = ArchivoTarzan.leerArchivo("../../Preparacion de la Prueba/Lote de Prueba/Entrada/02_NoSalta.in");
			ArchivoTarzan.escribirArchivo("../../Ejecucion de Prueba/Salida Obtenida/02_NoSalta.out",
					tarzan.resolver());

			tarzan = ArchivoTarzan.leerArchivo("../../Preparacion de la Prueba/Lote de Prueba/Entrada/03_NoLlega.in");
			ArchivoTarzan.escribirArchivo("../../Ejecucion de Prueba/Salida Obtenida/03_NoLlega.out",
					tarzan.resolver());

			tarzan = ArchivoTarzan.leerArchivo("../../Preparacion de la Prueba/Lote de Prueba/Entrada/04_Negativos.in");
			ArchivoTarzan.escribirArchivo("../../Ejecucion de Prueba/Salida Obtenida/04_Negativos.out",
					tarzan.resolver());

			tarzan = ArchivoTarzan
					.leerArchivo("../../Preparacion de la Prueba/Lote de Prueba/Entrada/05_DistanciasNoOrdenas.in");
			ArchivoTarzan.escribirArchivo("../../Ejecucion de Prueba/Salida Obtenida/05_DistanciasNoOrdenas.out",
					tarzan.resolver());

			tarzan = ArchivoTarzan
					.leerArchivo("../../Preparacion de la Prueba/Lote de Prueba/Entrada/06_BifurcacionDeCaminos.in");
			ArchivoTarzan.escribirArchivo("../../Ejecucion de Prueba/Salida Obtenida/06_BifurcacionDeCaminos.out",
					tarzan.resolver());

			for (int i = 0; i < 8; i++) {
				tarzan = ArchivoTarzan.leerArchivo(
						"../../Preparacion de la Prueba/Lote de Prueba/Entrada/LoteProfe_Tarzan/0" + i + ".in");
				ArchivoTarzan.escribirArchivo("../../Ejecucion de Prueba/Salida Obtenida/0" + i + ".out",
						tarzan.resolver());
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
