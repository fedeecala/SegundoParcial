package pa;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ArchivoTarzan {
	public static Tarzan leerArchivo(String path) throws FileNotFoundException {
		File archivo = new File(path);
		Scanner entrada = new Scanner(archivo);
		int numeroDeArbol = 0;
		List<Arbol> arboles = new ArrayList<>();
		while (entrada.hasNext()) {
			arboles.add(new Arbol(numeroDeArbol, entrada.nextInt(), entrada.nextInt()));
			numeroDeArbol++;
		}
		entrada.close();

		int cantidadDeArboles = arboles.size();
		Tarzan tarzan = new Tarzan(cantidadDeArboles);
		tarzan.setArboles(arboles);
		for (int i = 0; i < cantidadDeArboles; i++) {
			for (int j = 1 + i; j < cantidadDeArboles; j++) {
				if (ArchivoTarzan.calcularDistanciaEntreArboles(arboles.get(i), arboles.get(j))) {
					tarzan.setAdyacencia(arboles.get(i).getId(), arboles.get(j).getId());
				}
			}
		}

		return tarzan;
	}

	public static void escribirArchivo(String path, ArrayList<Arbol> arbol) throws FileNotFoundException {
		File archivo = new File(path);
		PrintWriter salida = new PrintWriter(archivo);

		if (arbol.isEmpty()) {
			salida.println("NO HAY RUTA");
		} else {

			for (int i = arbol.size() - 1; i >= 0; i--) {
				salida.println(arbol.get(i).getPosX() + " " + arbol.get(i).getPosY());

			}
		}
		salida.close();
	}

	public static boolean calcularDistanciaEntreArboles(Arbol a1, Arbol a2) {
		double distancia = Math
				.sqrt((double) (Math.pow(a2.getPosX() - a1.getPosX(), 2) + Math.pow(a2.getPosY() - a1.getPosY(), 2)));
		return distancia <= 50.00;
	}
}
