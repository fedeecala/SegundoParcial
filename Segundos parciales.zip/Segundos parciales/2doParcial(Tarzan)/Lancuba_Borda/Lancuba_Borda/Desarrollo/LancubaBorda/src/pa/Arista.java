package pa;

public class Arista implements Comparable<Arista> {
	private Arbol arbolOrigen;
	private Arbol arbolDestino;
	private int costo;

	public Arista(Arbol arbolOrigen, Arbol arbolDestino, int costo) {
		this.arbolOrigen = arbolOrigen;
		this.arbolDestino = arbolDestino;
		this.costo = costo;
	}
	
	public Arista(int arbol1, int arbol2, int costo) {
		this.arbolOrigen = new Arbol(arbol1);
		this.arbolDestino = new Arbol(arbol2);
		this.costo = costo;
	}
	
	public Arista(Arbol arbolOrigen, Arbol arbolDestino) {
		this.arbolOrigen = arbolOrigen;
		this.arbolDestino = arbolDestino;
		
	}

	public Arbol getArbolOrigen() {
		return arbolOrigen;
	}

	public Arbol getArbolDestino() {
		return arbolDestino;
	}

	public int getCosto() {
		return costo;
	}

	@Override
	public int compareTo(Arista o) {
		return this.costo - o.costo;
	}
}
