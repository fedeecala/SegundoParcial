package pa;

public class MatrizDeAdyacencia {
	private int[][] matriz;

	public MatrizDeAdyacencia(int cantidadDeArboles) {
		this.matriz = new int[cantidadDeArboles][];
		for (int i = 0; i < cantidadDeArboles; i++) {
			matriz[i] = new int[i];
		}
	}

	public void set(int fila, int columna) {
		if (columna == fila)
			return;
		if (columna > fila) {
			this.matriz[columna][fila] = 1;
			return;
		}

		this.matriz[fila][columna] = 1;
	}

	public int get(int fila, int columna) {
		if (columna == fila)
			return 0;
		if (columna > fila)
			return this.matriz[columna][fila];
		return this.matriz[fila][columna];
	}
}
