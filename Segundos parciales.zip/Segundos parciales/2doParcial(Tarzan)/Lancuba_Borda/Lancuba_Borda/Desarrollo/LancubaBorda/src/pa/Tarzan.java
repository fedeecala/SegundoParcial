package pa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

public class Tarzan {
	public static final int INFINITO = 99999;
	private MatrizDeAdyacencia matriz;
	private int cantidadDeArboles;
	private PriorityQueue<Arista> colaDeAristas;
	private int[] vectorDeCostos;
	private int[] vectorDePrecesores;
	private List<Arbol> arboles = new ArrayList<>();
	private ArrayList<Arbol> arbolesDeRecorrido = new ArrayList<>();

	public Tarzan(int cantidadDeArboles) {
		this.cantidadDeArboles = cantidadDeArboles;
		this.matriz = new MatrizDeAdyacencia(cantidadDeArboles);
		this.vectorDeCostos = new int[cantidadDeArboles];
		this.vectorDePrecesores = new int[cantidadDeArboles];
		this.colaDeAristas = new PriorityQueue<>();
	}

	public ArrayList<Arbol> resolver() {
		Arrays.fill(this.vectorDePrecesores, Tarzan.INFINITO);
		Arrays.fill(this.vectorDeCostos, Tarzan.INFINITO);
		for (int i = 0; i < this.cantidadDeArboles; i++) {
			if (matriz.get(0, i) == 1) {
				this.vectorDeCostos[i] = 1;
				this.vectorDePrecesores[i] = 0;				
			}
		}

		List<Arista> aristasAdycentesAW = new ArrayList<>();
		this.cargarColaDePrioridad();
		while (!colaDeAristas.isEmpty()) {
			Arista aristaW = this.colaDeAristas.poll();
			Arbol w = aristaW.getArbolDestino();
			int dW = this.vectorDeCostos[w.getId()];

			for (int i = 1; i < this.cantidadDeArboles; i++) {
				if (this.matriz.get(w.getId(), i) == 1) {
					aristasAdycentesAW.add(new Arista(w, new Arbol(i), 1));
				}
			}

			for (Arista aristaI : aristasAdycentesAW) {
				Arbol i = aristaI.getArbolDestino();
				int cI = this.vectorDeCostos[i.getId()];
				int cWI = aristaI.getCosto();
				if (cI > cWI + dW) {
					this.vectorDeCostos[i.getId()] = cWI + dW;
					this.vectorDePrecesores[i.getId()] = w.getId();
					this.colaDeAristas.add(new Arista(new Arbol(0), i, cWI + dW));
				}
			}
			aristasAdycentesAW.clear();
		}
		this.calcularArbolesDeSalto();
		return this.arbolesDeRecorrido;
	}

	private void cargarColaDePrioridad() {
		for (int i = 0; i < this.cantidadDeArboles; i++) {
			if (this.matriz.get(this.arboles.get(0).getId(), i) == 1 && i != 0) {
				this.colaDeAristas.add(new Arista(this.arboles.get(0).getId(), i, 1));
			}

		}
	}

	public void setAdyacencia(int arbol1, int arbol2) {
		this.matriz.set(arbol1, arbol2);
	}

	public void setArboles(List<Arbol> arboles) {
		this.arboles = arboles;
	}

	public void calcularArbolesDeSalto() {

		int arbolActual = this.cantidadDeArboles - 1;
		while (this.vectorDePrecesores[arbolActual] != Tarzan.INFINITO && this.vectorDePrecesores[arbolActual] != 0) {
			this.arbolesDeRecorrido.add(this.arboles.get(arbolActual));
			arbolActual = this.vectorDePrecesores[arbolActual];
		}
		
		if (this.vectorDePrecesores[arbolActual] == 0) {
			this.arbolesDeRecorrido.add(this.arboles.get(arbolActual));
			this.arbolesDeRecorrido.add(this.arboles.get(0));
		} else {
			this.arbolesDeRecorrido.clear();
		}
	}
}
