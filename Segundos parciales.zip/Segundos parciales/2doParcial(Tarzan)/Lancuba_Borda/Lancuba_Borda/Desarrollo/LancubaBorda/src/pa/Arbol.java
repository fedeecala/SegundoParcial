package pa;

public class Arbol {
	private int numeroDeArbol;
	private int posX;
	private int posY;

	public Arbol(int numeroDeArbol, int posX, int posY) {
		this.numeroDeArbol = numeroDeArbol;
		this.posX = posX;
		this.posY = posY;
	}
	
	public Arbol(int numeroDeArbol) {
		this.numeroDeArbol = numeroDeArbol;
	}

	public int getId() {
		return numeroDeArbol;
	}

	public int getPosX() {
		return posX;
	}

	public int getPosY() {
		return posY;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numeroDeArbol;
		result = prime * result + posX;
		result = prime * result + posY;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Arbol other = (Arbol) obj;
		if (numeroDeArbol != other.numeroDeArbol)
			return false;
		if (posX != other.posX)
			return false;
		if (posY != other.posY)
			return false;
		return true;
	}
}
