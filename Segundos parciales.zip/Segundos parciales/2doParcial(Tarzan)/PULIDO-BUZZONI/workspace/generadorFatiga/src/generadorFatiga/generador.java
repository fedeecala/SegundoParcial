package generadorFatiga;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class generador {
	
public static void main(String[] args) throws FileNotFoundException {
	PrintWriter salida = new PrintWriter(new File("C:\\Users\\laboratorios\\Desktop\\workspace\\Pulido-Buzzoni\\Pruebas\\IN\\fatiga.in"));
	
	for(int i=0;i<250;i++) {
		int x = 250;
		int y = 250;
		salida.println((x-i)+" "+(y-i));
	}
	for(int i=0;i<250;i++) {
		int x = -250;
		int y = 250;
		salida.println((x+i)+" "+(y-i));
	}
	for(int i=0;i<250;i++) {
		int x = 250;
		int y = -250;
		salida.println((x-i)+" "+(y+i));
	}
	for(int i=250;i>0;i--) {
		int x = -250;
		int y = -250;
		salida.println((x+i)+" "+(y+i));
	}
	salida.close();
}

}
