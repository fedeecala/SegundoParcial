package base;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class App {

	public static void main(String[] args) throws FileNotFoundException {
		String path = "pruebas/", nombre="saltode50";
		Grafo grafo = Archivo.leer(path+"IN/"+nombre+".in");
		Archivo.escribir(path+"OUT/"+nombre+".out", grafo.resolver());
		
		


	}

}
