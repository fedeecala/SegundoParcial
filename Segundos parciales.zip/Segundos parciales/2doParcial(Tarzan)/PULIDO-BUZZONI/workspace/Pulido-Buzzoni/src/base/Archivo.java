package base;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Archivo {

	public static Grafo leer(String path) throws FileNotFoundException {

		Scanner sc = new Scanner(new File(path));
		Arbol arbol;
		ArrayList<Arbol> listaNodos = new ArrayList<Arbol>();
		ArrayList<Arista> listaAristas = new ArrayList<Arista>();
		ArrayList<NodoAdyacente> listaAdyacentes[];
		
		int cantNodos = 0, x, y;
		
		while (sc.hasNextInt()) {
			x = sc.nextInt();
			y = sc.nextInt();
			arbol = new Arbol(x, y, cantNodos);
			listaNodos.add(arbol);
			cantNodos++;
		}
		sc.close();

		listaAdyacentes = new ArrayList[cantNodos];
		for(int i = 0; i<cantNodos;i++){
			listaAdyacentes[i] = new ArrayList<NodoAdyacente>();
		}
		
		for (int i = 0; i < cantNodos; i++) {
			for (int j = i + 1; j < cantNodos; j++) {
				Arbol arb1 = listaNodos.get(i);
				Arbol arb2 = listaNodos.get(j);
				if(arb1.puedoSaltar(arb2)) {
					listaAristas.add(new Arista(arb1, arb2));
					listaAdyacentes[i].add(new NodoAdyacente(arb2));
					listaAdyacentes[j].add(new NodoAdyacente(arb1));
				}
				
			}
		}
		return new Grafo(cantNodos,listaNodos,listaAristas,listaAdyacentes);
	}
	
	public static void escribir(String path,ArrayList<Arbol> arboles) throws FileNotFoundException {
		
		PrintWriter salida = new PrintWriter(path);
		if(arboles==null) {
			salida.println("NO HAY RUTA");
			salida.close();
			return ;
		}
		for(int i=arboles.size()-1;i>=0;i--) {
			salida.println(arboles.get(i).toString());
		}
		
		salida.close();
	}
}
