package base;

public class Arbol {

	private int x;
	private int y;
	private int numero;

	public Arbol(int x, int y, int numero) {

		this.x = x;
		this.y = y;
		this.numero = numero;
	}

	public int getNumero() {
		return numero;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public boolean puedoSaltar(Arbol arb) {

		if (Math.sqrt(Math.pow(this.x - arb.x, 2) + Math.pow(this.y - arb.y, 2)) <= 50.0) {
			return true;
		} else
			return false;
	}

	@Override
	public String toString() {
		return x + " " + y;
	}

}
