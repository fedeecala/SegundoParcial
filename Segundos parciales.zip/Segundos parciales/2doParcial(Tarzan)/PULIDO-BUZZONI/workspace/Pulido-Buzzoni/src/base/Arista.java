package base;

public class Arista {

	private Arbol nodo1;
	private Arbol nodo2;
	
	
	public Arista(Arbol nodo1, Arbol nodo2) {
	
		this.nodo1 = nodo1;
		this.nodo2 = nodo2;
	}
	public Arbol getNodo1() {
		return nodo1;
	}
	public Arbol getNodo2() {
		return nodo2;
	}
	
	
}
