package base;

public class NodoAdyacente  implements Comparable<NodoAdyacente>{
	private Arbol adyacente;
	private int costo;
	public NodoAdyacente(Arbol arb) {
		adyacente = arb;
		costo=1;
	}
	public NodoAdyacente(Arbol arb, int costo) {
		adyacente = arb;
		this.costo=costo;
	}

	public Arbol getAdyacente() {
		return adyacente;
	}

	public int getCosto() {
		return costo;
	}
	
	@Override
	public int compareTo(NodoAdyacente o) {
		
		return this.costo - o.costo;
	}
	

}
