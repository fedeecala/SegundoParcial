package base;

import java.util.*;


import base.Arbol;

public class Grafo {
	private final  static int INFINITO =80000;
	private int cantNodos;
	private ArrayList<Arbol> nodos;
	private ArrayList<Arista> listaAristas;
	private ArrayList<NodoAdyacente> listaAdyacentes[];

	public Grafo(int cantNodos, ArrayList<Arbol> nodos, ArrayList<Arista> listaAristas,
			ArrayList<NodoAdyacente>[] listaAdyacentes) {

		this.cantNodos = cantNodos;
		this.nodos = nodos;
		this.listaAristas = listaAristas;
		this.listaAdyacentes = listaAdyacentes;
	}

	// O(nlogn)
	public ArrayList<Arbol> resolver() {
	
		Integer camino[]= new Integer[cantNodos];
		PriorityQueue<NodoAdyacente> colap= new PriorityQueue<NodoAdyacente>();
		boolean permanente[] = new boolean [cantNodos];
		int costos[] = new int[cantNodos];
		colap.add(new NodoAdyacente(nodos.get(0),0));
		
		ArrayList<Arbol>caminoArboles = new ArrayList<Arbol>();
		
		for(int i =0;i<cantNodos;i++) {
			costos[i]=INFINITO;
			camino[i]=-1;
		}
		camino[0]=0;
		costos[0]=0;
		
		while(!colap.isEmpty()) {
			int nodoActual=colap.poll().getAdyacente().getNumero();
			permanente[nodoActual]=true;
			
			for(int i = 0; i < listaAdyacentes[nodoActual].size() ;i++) {
				NodoAdyacente nodoAdy = listaAdyacentes[nodoActual].get(i);
				int nodo = nodoAdy.getAdyacente().getNumero();
				if(!permanente[nodo] && costos[nodo] > costos[nodoActual]+nodoAdy.getCosto()){
					costos[nodo]=costos[nodoActual]+nodoAdy.getCosto();
					camino[nodo]=nodoActual;
					colap.add(nodoAdy);
				}
			}
			
		}
		if(costos[cantNodos-1]==INFINITO)
			return null;
		
		int nodoAnterior = camino[cantNodos-1];
		int nodoSiguiente = cantNodos-1;
		
		while(nodoAnterior!=nodoSiguiente){
			caminoArboles.add(nodos.get(nodoSiguiente));
			nodoSiguiente = nodoAnterior;
			nodoAnterior= camino[nodoAnterior];
		}
		caminoArboles.add(nodos.get(0));
		return caminoArboles;
		
	}
}
