package GeneradorFatiga;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CasoFatiga {

	private static int mat[][];
	private static int dist=0;
	
	public static void main(String[] args) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("In/06_Fatiga.in"));
			mat = new int[1000][1000];
			for (int i = 0; i < 1000; i++) {
				mat[i][0] = dist;
				mat[0][i] = 0;
				dist+=50;
				bw.write(mat[i][0] + " " + mat[0][i] +"\n");
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
