package Parcial2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Tarzan {

	private static String pathIn = "In/06_Fatiga.in";
	private static String pathOut = "Out/06_Fatiga.out";
	
	private ArrayList<Nodo> nodos = new ArrayList<>();
	private int nodoOrigen;
	private int nodoDestino;
	private double distancias[][];
	private int cantNodos;
	
	private boolean[] visitados;
	private double[] costos;
	private int[] ruta;
	private int cantidadNodos;
	
	public Tarzan(String pathIn){
		try {
			Scanner sc = new Scanner(new File(pathIn));
			
			while(sc.hasNextInt()){
				nodos.add(new Nodo(sc.nextInt(), sc.nextInt()));
			}
			
			nodoOrigen = 0;
			nodoDestino = nodos.size();
			this.cantNodos = nodos.size();
			
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static double calcularDistancias(Nodo i, Nodo j){
		int auxX = (i.x)-(j.x);
		int auxY = (i.y)-(j.y);
		double distancia = Math.sqrt(Math.pow(auxX, 2) + Math.pow(auxY, 2));
		if(distancia <= 50){
			return distancia;
		}else{
			return Integer.MAX_VALUE;
		}
	}
	
	public void cargarMatAdy(ArrayList<Nodo> n){
		distancias = new double[this.nodos.size()][this.nodos.size()];
		
		for (int i = 0; i < n.size(); i++) {
			for (int j = i+1; j < n.size(); j++) {
				distancias[i][j] = distancias[j][i] = calcularDistancias(n.get(i), n.get(j));
			}
		}
	}

	public void Dijsktra(double[][] matrizAdyacencia, final int nodoInicio) {
		this.distancias = matrizAdyacencia;
		this.nodoOrigen = 0;
		this.cantidadNodos = matrizAdyacencia.length;
		this.visitados = new boolean[this.cantNodos];
		this.costos = new double[this.cantNodos];
		this.ruta = new int[this.cantNodos];
		inicializarVectores();
		this.visitados[0] = true;
		this.costos[0] = Integer.MAX_VALUE;
		int i = 0;
		int siguiente = minimo();
		while (i < cantidadNodos && siguiente != -1) {
			visitados[siguiente] = true;
			for (int adyacente = 0; adyacente < cantidadNodos; adyacente++) {
				if (!visitados[adyacente]) {
					if (distancias[siguiente][adyacente] != Integer.MAX_VALUE
							&& (costos[siguiente] + distancias[siguiente][adyacente]) < costos[adyacente]) {
						costos[adyacente] = costos[siguiente] + distancias[siguiente][adyacente];
						ruta[adyacente] = siguiente;
					}
				}
			}
			siguiente = minimo();
		}
	}
	
	private int minimo() {
		double valorMinimo = Integer.MAX_VALUE;
		int indiceMinimo = -1;
		for (int i = 0; i < cantidadNodos; i++) {
			if (!visitados[i] && costos[i] < valorMinimo) {
				valorMinimo = costos[i];
				indiceMinimo = i;
			}
		}
		return indiceMinimo;
	}
	private void inicializarVectores() {
		for (int i = 0; i < cantidadNodos; i++) {
			costos[i] = this.distancias[0][i];
			ruta[i] = -1;
		}
	}
	
	public void escribirSalida(String pathOut){
		
		try {
			BufferedWriter bf = new BufferedWriter(new FileWriter(pathOut));
			
			Stack<Integer> pila = new Stack<Integer>();
			int anterior = this.nodoDestino - 1;
			if (this.costos[anterior] != Integer.MAX_VALUE) {
				//System.out.println(this.nodos.get(this.nodoOrigen).x +" "+ this.nodos.get(this.nodoOrigen).y );
				bf.write(this.nodos.get(this.nodoOrigen).x +" "+ this.nodos.get(this.nodoOrigen).y);
				while (ruta[anterior] != -1) {
					pila.push(ruta[anterior]);
					anterior = ruta[anterior];
				}
				while (!pila.isEmpty()) {
					int aux = pila.pop();
					bf.write(("\n" +this.nodos.get(aux).x +" "+ this.nodos.get(aux).y));
				}
				bf.write("\n" + this.nodos.get(this.nodoDestino-1).x +" " + this.nodos.get(this.nodoDestino-1).y);
				
			} else {
				bf.write("NO HAY RUTA");
			}
			
			bf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

public static void main(String[] args) {
	Tarzan t = new Tarzan(pathIn);
	t.cargarMatAdy(t.nodos);
	t.Dijsktra(t.distancias, 0);
	t.escribirSalida(pathOut);
	}
}
