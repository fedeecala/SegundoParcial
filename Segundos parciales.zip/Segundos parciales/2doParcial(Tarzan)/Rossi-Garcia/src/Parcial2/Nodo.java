package Parcial2;

public class Nodo {

	int x;
	int y;
	double distancia[][];
	
	public Nodo(int xx, int yy){
		this.x = xx;
		this.y = yy;
	}

	
	
}
