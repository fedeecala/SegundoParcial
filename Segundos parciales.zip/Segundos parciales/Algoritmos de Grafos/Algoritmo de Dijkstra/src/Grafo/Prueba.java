package Grafo;

public class Prueba {


	public static void main(String[] args) {
		Grafo g1 = new Grafo("E:/Users/ariel/Desktop/Algoritmos de Grafos/Algoritmo de Dijkstra/grafo.txt");
        g1.Dijkstra();
		g1.MostrarDistancias();
		g1.Caminos();
	}

}
