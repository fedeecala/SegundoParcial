package Grafo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Grafo {
	private Integer CantidadDeNodos;
	private Integer Adyacencia[][]; 
	private Integer Camino[];
	private Integer Vistos[];
	private Integer Distacias[]; 
	private Integer NodoActual;
	private Integer NodoAdy;
	
	public void InicializarMatriz(){

		this.Adyacencia =  new Integer[this.CantidadDeNodos][this.CantidadDeNodos];
		
		for(int i=0;i<this.CantidadDeNodos;i++)
			for(int j=0; j < this.CantidadDeNodos;j++)
		    	this.Adyacencia[i][j]=-1;
	}
	
	public void InicializarVistos(){
		
		this.Vistos = new Integer[this.CantidadDeNodos];
		
		for(int i=0;i<this.CantidadDeNodos;i++)
			this.Vistos[i] =-1; 
	}
	
	public void InicializarDistacias(){
		this.Distacias = new Integer[this.CantidadDeNodos];
		for(int i=0;i<this.CantidadDeNodos;i++)
			this.Distacias[i]= 1000000;
	}
	public void InicializarCamino(){
		this.Camino = new Integer[this.CantidadDeNodos];
		for(int i=0;i<this.CantidadDeNodos;i++)
			this.Camino[i]=i;
	}

	public Grafo(String Ruta){
		this.NodoAdy = -1;
		this.NodoActual = -1;
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;
		String cadena; 
		String[] info;
		
		try {
			archivo = new File(Ruta);
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
		    cadena = br.readLine();
		    info = cadena.split(" ");
			Integer arcos;
			
		 	this.CantidadDeNodos = Integer.parseInt(info[0]);
		 	arcos = Integer.parseInt(info[1]);
			this.InicializarMatriz();
			this.InicializarVistos();
			this.InicializarDistacias();
			this.InicializarCamino();
	
			for (int J = 0; J < arcos; J++) {
				cadena = br.readLine();
				info = cadena.split(" ");
				this.Adyacencia[Integer.parseInt(info[0])-1][Integer.parseInt(info[1])-1] = Integer.parseInt(info[2]);
				this.Adyacencia[Integer.parseInt(info[1])-1][Integer.parseInt(info[0])-1] = Integer.parseInt(info[2]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (fr != null)
					fr.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}	
	
	public int ObtenerSiguienteAdy(){
	 	  
		boolean encontrado = false;
	    this.NodoAdy++;
	    
	    while(!encontrado && (this.NodoAdy <= this.CantidadDeNodos-1)){
	    	if((this.NodoAdy != this.NodoActual) && (this.Adyacencia[this.NodoActual][this.NodoAdy])!= -1)
	    		encontrado = true;
	    	else
	    		this.NodoAdy++; 
	    } 
	    
	    if(encontrado)
	    	return this.NodoAdy;
	    else{
	        this.NodoAdy=-1;
	        return -1;
	    }    
	}
	
	public int ObtenerSiguienteVisto(int actual){
		
		int Posicion = actual + 1;
		
		while(Posicion < this.Vistos.length && this.Vistos[Posicion] == -1)
			Posicion++;
		
		if (Posicion == this.Vistos.length)
		 return -1;
		else
		 return Posicion;	 
	}
	
    public int ObtenerSiguienteNoVisto(int actual){
		
		int Posicion = actual + 1;
		
		while(Posicion < this.Vistos.length && this.Vistos[Posicion] != -1)
			Posicion++;
		
		if (Posicion == this.Vistos.length)
		 return -1;
		else
		 return Posicion;	 
	}
	
	public int ObtenerMenor(){
	   Integer menor=0;
	   int PosMenor = 0;
	   boolean flag = true;
	   
	   for(int i=0;i<this.CantidadDeNodos;i++){
		   if(this.Vistos[i]==-1 && flag){
			   menor=this.Distacias[i];
			   PosMenor=i;
			   flag=false;
		   }	
		   else
			   if( this.Vistos[i]==-1 && this.Distacias[i]<=menor){
				   menor=this.Distacias[i];
				   PosMenor=i;
			   }
				   
	   }
	   return PosMenor;
		
	}
	
	public void Dijkstra(){
		this.NodoActual = 0;
		this.NodoAdy=-1;
		this.Distacias[0]=0;
		this.Vistos[0]=1;
	    Integer NodosVistos=1;
	    
	    while(this.ObtenerSiguienteAdy()!=-1){
	    	this.Distacias[this.NodoAdy]= this.Adyacencia[this.NodoActual][this.NodoAdy];
	    	this.Camino[this.NodoAdy]=this.NodoActual;
	    }
	    
		while(NodosVistos != this.CantidadDeNodos){
			this.NodoActual = this.ObtenerMenor();
			this.Vistos[this.NodoActual]=1;
			NodosVistos++;
					
			while(this.ObtenerSiguienteAdy()!=-1){
				if(this.Vistos[this.NodoAdy]==-1){
				  if(this.Distacias[this.NodoAdy]>this.Distacias[this.NodoActual]+this.Adyacencia[this.NodoActual][this.NodoAdy]){
					
					  this.Distacias[this.NodoAdy]=this.Distacias[this.NodoActual]+this.Adyacencia[this.NodoActual][this.NodoAdy];
					  this.Camino[this.NodoAdy]= this.NodoActual;
				  }  
				}	
			}
		}
	}
	
	public void MostrarDistancias(){
		for(int i=0;i<this.CantidadDeNodos;i++)
			System.out.println("Nodo:"+(i+1)+": "+this.Distacias[i]);
	}
	
	public void MostrarCamino(int vertice){
		System.out.print(vertice+1+" ");
		if(this.Camino[vertice]!=vertice)
		  this.MostrarCamino(this.Camino[vertice]);
	}
	
	public void Caminos(){
		System.out.print("\nCaminos:");
		for(int i=0;i<this.CantidadDeNodos;i++){
			System.out.println("\n");
			this.MostrarCamino(i);
		}	
	}
}
