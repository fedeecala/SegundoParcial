package Grafo;

public class Prueba {

	
	public static void main(String[] args) throws Exception {
	 Grafo g1 = new Grafo("E:/Users/ariel/Documents/Facultad/Programacion Avanzada/Sabados/Algoritmo prim/grafo.txt");
	 int c = g1.ObtenerArbolArbaMin();
     System.out.println(c);
     g1.MostrarArbolReducido();
	}

}
