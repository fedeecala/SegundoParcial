package Grafo;

public class Prueba {

	public static void main(String[] args) throws Exception {
	  Grafo g1= new Grafo("E:/Users/ariel/workspace/Algoritmo de Kruskal/grafo.txt");
	  g1.OrdenarCostos();
	  Integer c = g1.ObtenerArbolAbarMin();
      System.out.println(c);
      g1.MostrarArbolReducido();
     
	}
}
